<footer class="footer">
    2022 © Semeton BUMDes
</footer>