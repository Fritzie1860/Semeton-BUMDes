<p>&nbsp;</p>
<table style="border: none;border-collapse: collapse;width:964pt;">
    <tbody>
        <tr>
            <td colspan="10" style="color:black;font-size:21px;font-weight:700;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:20.25pt;width:964pt;">BUMDES PUTRI NYALE DESA KUTA</td>
        </tr>
        <tr>
            <td colspan="10" style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;">BUKU BANK&nbsp;</td>
        </tr>
        <tr>
            <td colspan="10" style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;">TAHUN ANGGARAN 2018</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;height:15.75pt;">Kecamatan &nbsp; &nbsp; &nbsp; &nbsp;: Pujut</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:none;">&nbsp; Bulan</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:none;">:Desember 2018</td>
        </tr>
        <tr>
            <td colspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;height:15.75pt;">Kabupaten &nbsp; &nbsp; &nbsp; &nbsp;: Lombok Tengah</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Bank Cabang</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:none;">: Bank BRI Unit Sengkol</td>
        </tr>
        <tr>
            <td colspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:none;height:15.75pt;">Provinsi &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : &nbsp;Nusa Tenggara Barat</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Rekening No</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:none;">: 4709-01-019395-53-7</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td rowspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;height:47.25pt;width:48pt;">No.</td>
            <td rowspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;width:80pt;">TANGGAL TRANSAKSI</td>
            <td rowspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;width:156pt;">URAIAN TRANSAKSI</td>
            <td rowspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;width:89pt;">BUKTI TRANSAKSI</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-left:none;width:170pt;">PEMASUKAN</td>
            <td colspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-left:none;width:309pt;">PENGELUARAN</td>
            <td rowspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;width:112pt;">SALDO</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;height:15.75pt;border-top:none;border-left:none;width:89pt;">TRANSFER</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:81pt;">BUNGA BANK</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:124pt;">PENARIKAN</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:96pt;">PAJAK&nbsp;</td>
            <td rowspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;width:89pt;">BIAYA ADMINISTRASI (Rp.)</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;height:15.75pt;border-top:none;border-left:none;width:89pt;">(Rp.)</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:81pt;">(Rp.)</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:124pt;">(Rp.)</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:96pt;">(Rp.)</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;height:15.75pt;border-top:none;width:48pt;">1</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:80pt;">2</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:156pt;">3</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:89pt;">4</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:89pt;">5</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:81pt;">6</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:124pt;">7</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:96pt;">8</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:89pt;">9</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:#B7DEE8;border-top:none;border-left:none;width:112pt;">10</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;">1</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;">13-Sep-18</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;">Saldo Awal</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">100.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;">0</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;">0</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;">0</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">0</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;">100.000,00</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;">2</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;">16-Sep-18</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;">Biaya administrasi</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">5.500</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;">94.500,00</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;">2</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;">17-Sep-18</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;">Terima dana dari Pemdes</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">140.000.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;">0</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;">140.094.500,00</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;">3</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:italic;text-decoration:none;font-family:Cambria, serif;text-align:left;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;">18-Jul-19</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;">tarik dana dari rekening</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;">140.000.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;">94.500,00</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;border-top:none;width:48pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:80pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:156pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:112pt;"><br></td>
        </tr>
        <tr>
            <td colspan="4" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;width:373pt;">TOTAL TRANSAKSI BULAN INI</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">140.100.005</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;">140.000.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">5.500</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:white;border-top:none;border-left:none;width:112pt;">94.505,00</td>
        </tr>
        <tr>
            <td colspan="4" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:justify;vertical-align:middle;border:.5pt solid windowtext;height:15.75pt;width:373pt;">TOTAL TRANSAKSI KUMULATIF</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">140.100.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:81pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:124pt;">140.000.000</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:96pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;border-top:none;border-left:none;width:89pt;">5.500</td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:.5pt solid windowtext;background:white;border-top:none;border-left:none;width:112pt;">94.500</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td colspan="3" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Kuta,31 Desember 2018</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td colspan="4" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Disetujui Oleh,</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Dibuat Oleh,</td>
        </tr>
        <tr>
            <td colspan="4" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:65.25pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
        </tr>
        <tr>
            <td colspan="4" style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:underline;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:underline;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:underline;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:underline;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">(EMUR)</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:700;font-style:normal;text-decoration:underline;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">( MARIANAH )</td>
        </tr>
        <tr>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;height:15.75pt;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:general;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;"><br></td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Ketua &nbsp;Bumdes</td>
            <td colspan="2" style="color:black;font-size:16px;font-weight:400;font-style:normal;text-decoration:none;font-family:Cambria, serif;text-align:center;vertical-align:middle;border:none;">Bendahara&nbsp;</td>
        </tr>
    </tbody>
</table>