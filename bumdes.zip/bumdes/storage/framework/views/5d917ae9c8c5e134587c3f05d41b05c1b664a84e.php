<footer class="footer">
    2022 © Semeton BUMDes
</footer><?php /**PATH F:\Xampp\Project_Source\bumdes\resources\views/template/footer.blade.php ENDPATH**/ ?>