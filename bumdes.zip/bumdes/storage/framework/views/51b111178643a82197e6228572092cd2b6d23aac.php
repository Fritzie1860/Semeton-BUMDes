<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <div class="user-details">
            <div class="text-center">
                <?php $__currentLoopData = $profilbumdes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href=""></a><img src="/images/upload/<?php echo e($item['foto']); ?>" alt=""
                        class="img-circle"></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="user-info">
                <div class="dropdown m-t-5">
                    <!--  -->
                    
                    <h5><a href="<?php echo e(route('bumdes.index')); ?>" class="text-white">BUMDes Kuta Mandalika</a></h5>
                    
                    
                    
                    
                    <!--  -->
                    
                </div>

                
            </div>
        </div>
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect"><i class="ion-android-user-menu"></i><span>
                            Dashboard </span></a>
                </li>


                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ion-android-note"></i> <span> Master
                            Data</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('pengelola.index')); ?>">Pengelola</a></li>
                        <li><a href="<?php echo e(route('dataakun')); ?>">Data Akun</a></li>
                        <li><a href="<?php echo e(route('pemasok.index')); ?>">Pemasok</a></li>
                        <li><a href="<?php echo e(route('pelanggan.index')); ?>">Pelanggan</a></li>
                        <li><a href="<?php echo e(route('hutang.index')); ?>">Data hutang</a></li>
                        <!-- <li><a href="ui-progressbars.html">Data Investor</a></li> Note: Future Development -->
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-group"></i> <span> Jasa</span>
                        <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="">Transaksi Jasa</a></li>
                        <li><a href="">Beban</a></li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-shopping-basket"></i> <span>
                            Dagang</span> <span class="pull-right"><i class="mdi mdi-plus"></i></span></a>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo e(route('transaksi.index') . '?t=pembelian'); ?>">Pembelian</a></li>
                        <li><a href="<?php echo e(route('transaksi.index') . '?t=penjualan'); ?>">Penjualan</a></li>
                        <li><a href="">Beban</a></li>
                    </ul>
                </li>

                <!-- <li>
                    <a href="index.html" class="waves-effect"><i class="ti-home"></i><span> Bagi Hasil </span></a>
                </li> Note: Future Development-->

                <li>
                    <a href="<?php echo e(Route('barang.index')); ?>" class="waves-effect"><i class="fa fa-cubes"></i><span>
                            Persediaan
                            Barang
                        </span></a>
                </li>

                <li>
                    <a href="/laporan" class="waves-effect"><i class="fa fa-bar-chart-o"></i><span> Laporan </span></a>
                </li>

            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
<?php /**PATH F:\Xampp\Project_Source\bumdes\resources\views/template/sidebar.blade.php ENDPATH**/ ?>