

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-header-title">
                        <h4 class="pull-left page-title">Pengelola</h4>
                        
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Daftar Pengelola</h3>

                        </div>

                        <div class="panel-body">
                            <div class="row mt-2">
                                
                                <button class="btn btn-primary mb-2 pb-2" style="margin-bottom: 25px" data-toggle="modal"
                                    data-target="#tambah"> Tambah pengelola </button>
                                
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table id="datatable-responsive"
                                        class="table table-hover table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center;">No</th>
                                                <th style="text-align: center;">Nama Pengelola</th>
                                                <th style="text-align: center;">Status Posisi</th>
                                                <th style="text-align: center;">Nomor Telepon</th>
                                                <th style="text-align: center;">Foto Profil</th>
                                                
                                                <th style="text-align: center;">Aksi</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pengelola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <div class="conbtn">
                                                            <?php echo e($loop->iteration); ?>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php echo e($item->nama); ?>

                                                        
                                                    </td>
                                                    <td>
                                                        <?php echo e($item->status); ?>

                                                        
                                                    </td>
                                                    <td>
                                                        <?php echo e($item->kontak); ?>

                                                        
                                                    </td>
                                                    <td>
                                                        <div class="conbtn">
                                                            
                                                        </div>
                                                    </td>
                                                    
                                                    <td>

                                                        <div class="conbtn">
                                                            <button class="btn btn-primary center fa fa-edit"
                                                                data-toggle="modal" data-target="#edit"
                                                                onclick="edit_data('<?php echo e(route('pengelola.update', ['pengelola' => $item->id])); ?>', '<?php echo e($item->nama); ?>', '<?php echo e($item->status); ?>','<?php echo e($item->kontak); ?>', '<?php echo e($item->id); ?>', '<?php echo e($item->username); ?>')"></button>

                                                            <a href="#" class="delete"
                                                                data-id="<?php echo e($item['id']); ?>"></button></a>
                                                            <form id="#delete-post-form "
                                                                action="<?php echo e(route('pengelola.destroy', ['pengelola' => $item->id])); ?>"
                                                                method="post">
                                                                <?php echo method_field('delete'); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button
                                                                    class="btn btn-danger center fa fa-trash delete-user"
                                                                    style="margin-left: 2%">
                                                            </form>
                                                        </div>

                                                    </td>
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- End Row -->


        </div> <!-- container -->

    </div> <!-- content -->

    <!-- sample modal content -->
    <div id="tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Tambah Data Pengelola</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('pengelola.store')); ?>" method="POST" class="form-horizontal" role="form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="col-md-4 control-label">Nama Pengelola</label>
                            <div class="col-md-8">
                                <input name="nama" type="text" class="form-control"
                                    placeholder="Nama Lengkap Pengelola" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Nomor Telepon</label>
                            <div class="col-md-8">
                                <input name="kontak" data-parsley-type="number" type="text" class="form-control"
                                    placeholder="08XXXXXXXXXX" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Username</label>
                            <div class="col-md-8">
                                <input name="username" type="text" class="form-control" placeholder="Username" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Password</label>
                            <div class="col-md-8">
                                <input name="password" data-parsley-type="string" type="text" class="form-control"
                                    placeholder="password" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label">Status Pengelola</label>
                            <div class="col-sm-8">
                                <select name="status" class="form-control" required>
                                    <option value="Bendahara">Bendahara</option>
                                    <option value="Accounting">Pencatat Transaksi</option>
                                </select>
                            </div>
                        </div>

                        <div class="modal-footer">

                            <button type="button" class="btn btn-default waves-effect m-l-5"
                                data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>

                        </div>
                    </form>
                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- Modal Edit-->
    <div id="edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Edit Data Pengelola</h4>
                </div>
                <div class="modal-body">
                    <form action="" id="edit_form" method="POST" class="form-horizontal" role="form">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="edit_id">
                        <div class="form-group">
                            <label class="col-md-4 control-label">Nama Pengelola</label>
                            <div class="col-md-8">
                                <input name="nama" type="text" class="form-control" id="edit_nama"
                                    placeholder="Nama Lengkap Pengelola" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Nomor Telepon</label>
                            <div class="col-md-8">
                                <input name="kontak" data-parsley-type="number" type="text" class="form-control"
                                    id="edit_kontak" placeholder="08XXXXXXXXXX" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Username</label>
                            <div class="col-md-8">
                                <input name="username" type="text" class="form-control" placeholder="Username"
                                    id="edit_username" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Password</label>
                            <div class="col-md-8">
                                <input name="password" data-parsley-type="string" type="text" class="form-control"
                                    id="edit_password" placeholder="password" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label">Status Pengelola</label>
                            <div class="col-sm-8">
                                <select name="status" class="form-control" required>
                                    <option value="Bendahara" id="option-bendahara">Bendahara</option>
                                    <option value="Accounting" id="option-pencatat-transaksi">Pencatat Transaksi
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="modal-footer">

                            <button type="button" class="btn btn-default waves-effect m-l-5"
                                data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                        </div>
                    </form>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $('.delete-user').on('click', function(e) {
            e.preventDefault();
            var form = $(this).parents('form');
            // var id= $(this).attr('data-id');
            swal({
                    title: "Ingin Menghapus?",
                    text: "Kamu akan menghapus data pengelola",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        swal("Data Berhasil Dihapus !", {
                            icon: "success",
                        });
                        form.submit();
                    }

                });
        });
    </script>
    <script>
        function edit_data(url, nama, status, kontak, id, username) {
            document.getElementById("edit_form").action = url;
            document.getElementById("edit_id").value = id;
            document.getElementById("edit_nama").value = nama;
            document.getElementById("edit_kontak").value = kontak;
            document.getElementById("edit_username").value = username;

            if (status == "Bendahara") {
                document.getElementById("option-bendahara").selected = true;
                document.getElementById("option-pencatat-transaksi").selected = false;
            } else if (status == "Accounting") {
                document.getElementById("option-bendahara").selected = false;
                document.getElementById("option-pencatat-transaksi").selected = true;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Xampp\Project_Source\bumdes\resources\views/fitur/pengelola.blade.php ENDPATH**/ ?>