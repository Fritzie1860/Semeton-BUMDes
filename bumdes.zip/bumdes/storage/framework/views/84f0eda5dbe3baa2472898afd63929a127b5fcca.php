<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-header-title">
                        <h4 class="pull-left page-title">Pemasok</h4>
                        
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php if(session()->has('success')): ?>
                    <?php echo e(session('success')); ?>

                <?php endif; ?>
                
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Daftar Pemasok</h3>

                        </div>

                        <div class="panel-body">
                            <div class="row mt-2">
                                <button class="btn btn-primary mb-2 pb-2" style="margin-bottom: 25px" data-toggle="modal"
                                    data-target="#tambah"> Tambah Pemasok </button>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table id="datatable-responsive"
                                        class="table table-hover table-bordered dt-responsive nowrap" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center;">No</th>
                                                <th style="text-align: center;">Nama Pemasok</th>
                                                <th style="text-align: center;">Nomor Telepon</th>
                                                <th style="text-align: center;">Alamat Pemasok</th>
                                                <th style="text-align: center;">Aksi</th>
                                            </tr>
                                        </thead>


                                        
                                        <?php $__currentLoopData = $pemasok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="conbtn">
                                                        <?php echo e($loop->iteration); ?>

                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo e($item->nama); ?>

                                                    
                                                </td>
                                                <td>
                                                    <?php echo e($item->kontak); ?>

                                                    
                                                </td>
                                                <td>
                                                    <?php echo e($item->alamat); ?>

                                                    
                                                </td>
                                                <td>
                                                    <div class="conbtn">
                                                        <button class="btn btn-primary center fa fa-edit"
                                                            data-toggle="modal" data-target="#edit"
                                                            onclick="edit_data('<?php echo e($item->nama); ?>', '<?php echo e($item->kontak); ?>', '<?php echo e($item->alamat); ?>', '<?php echo e(route('pemasok.update', ['pemasok' => $item->id])); ?>')">
                                                        </button>

                                                        <form method="POST"
                                                            action="<?php echo e(route('pemasok.destroy', ['pemasok' => $item->id])); ?>"
                                                            class="form-horizontal" role="form">
                                                            <?php echo method_field('delete'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            

                                                            <button class="btn btn-danger center fa fa-trash"
                                                                style="margin-left: 2%"></button>
                                                        </form>

                                                        <button class="btn btn-success center mdi mdi-eye"
                                                            style="margin-left: 2%"
                                                            onclick="window.location.href='<?php echo e(route('pemasok.show', ['pemasok' => $item->id])); ?>'">
                                                            Barang</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- End Row -->


        </div> <!-- container -->

    </div> <!-- content -->

    <!-- sample modal content -->
    <div id="tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Tambah Data Pemasok</h4>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('pemasok.store')); ?>" class="form-horizontal" role="form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status" value="pemasok">
                        <div class="form-group">
                            <label class="col-md-4 control-label">Nama Pemasok</label>
                            <div class="col-md-8">
                                <input name="nama" type="text" class="form-control" id="nama"
                                    placeholder="Nama Pemasok atau Nama Perusahaannya" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Nomor Telepon</label>
                            <div class="col-md-8">
                                <input name="kontak" data-parsley-type="number" type="text" class="form-control"
                                    id="kontak" placeholder="08XXXXXXXXXX" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Alamat Pemasok</label>
                            <div class="col-md-8">
                                <input name="alamat" type="text" class="form-control" id="alamat"
                                    placeholder="Alamat Pemasok atau Alamat Perusahaannya" required>
                            </div>
                        </div>

                        <div class="modal-footer">

                            <button type="button" class="btn btn-default waves-effect m-l-5"
                                data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                        </div>
                    </form>
                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <!-- sample modal edit -->
    <div id="edit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Edit Data Pemasok</h4>
                </div>
                <div class="modal-body">

                    <form action="" method="POST" class="form-horizontal" role="form" id="form_update">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label class="col-md-4 control-label">Nama Pemasok</label>
                            <div class="col-md-8">
                                <input name="nama" id="edit_nama" type="text" class="form-control"
                                    placeholder="Nama Pemasok atau Nama Perusahaannya" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Nomor Telepon</label>
                            <div class="col-md-8">
                                <input name="kontak" id="edit_kontak" data-parsley-type="number" type="text"
                                    class="form-control" placeholder="08XXXXXXXXXX" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Alamat Pemasok</label>
                            <div class="col-md-8">
                                <input name="alamat" id="edit_alamat" type="text" class="form-control"
                                    id="alamat" placeholder="Alamat Pemasok atau Alamat Perusahaannya" required>
                            </div>
                        </div>

                        <div class="modal-footer">

                            <button type="button" class="btn btn-default waves-effect m-l-5"
                                data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                        </div>
                    </form>

                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function edit_data(nama, kontak, alamat, url) {
            console.log(nama, kontak, alamat, url);
            document.getElementById("form_update").action = url;
            document.getElementById("edit_nama").value = nama;
            document.getElementById("edit_kontak").value = kontak;
            document.getElementById("edit_alamat").value = alamat;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Xampp\Project_Source\bumdes\resources\views/fitur/pemasok.blade.php ENDPATH**/ ?>